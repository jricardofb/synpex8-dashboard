import type { FastifyInstance } from "fastify";
import type { PrismaClient } from "@prisma/client";

type Options = { prisma: PrismaClient };

export async function accountsRoutes(app: FastifyInstance, opts: Options) {
  const { prisma } = opts;

  const fail = (reply: any, msg: string, err: unknown) => {
    console.error(msg, err);
    return reply.status(500).send({
      error: msg,
      detail: err instanceof Error ? err.message : String(err),
    });
  };

  app.get("/api/v1/accounts", async (_req, reply) => {
    try {
      const rows = await prisma.account.findMany({ orderBy: { createdAt: "desc" } });

      const data = rows.map((a) => ({
        id: String(a.id),
        broker: a.broker,
        active: a.active,
        freeMargin: Number(a.freeMargin ?? 0),
        reservedMargin: Number(a.reservedMargin ?? 0),
        usableMargin: Number(a.freeMargin ?? 0) - Number(a.reservedMargin ?? 0),
      }));

      return { data };
    } catch (err) {
      return fail(reply, "Falha ao listar contas", err);
    }
  });

  app.get("/api/v1/clients", async (_req, reply) => {
    try {
      const data = await prisma.client.findMany({ orderBy: { createdAt: "desc" } });
      return { data };
    } catch (err) {
      return fail(reply, "Falha ao listar clients", err);
    }
  });

  app.get("/api/v1/masters", async (_req, reply) => {
    try {
      const data = await prisma.master.findMany({
        select: { id: true, externalId: true, active: true, createdAt: true, updatedAt: true },
        orderBy: { createdAt: "desc" },
      });
      return { data };
    } catch (err) {
      return fail(reply, "Falha ao listar masters", err);
    }
  });

  app.get("/api/v1/universal-assets", async (_req, reply) => {
    try {
      const data = await prisma.universalAsset.findMany({ orderBy: { code: "asc" } });
      return { data };
    } catch (err) {
      return fail(reply, "Falha ao listar ativos", err);
    }
  });
}
