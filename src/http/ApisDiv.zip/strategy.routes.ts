import type { FastifyInstance } from 'fastify';
import type { AppPrisma } from '../config/prisma.js';
import { ZodError } from 'zod';
import {
  createStrategyService,
  strategySchema,
  strategyUpdateSchema,
  StrategyNotFoundError,
  StrategyInUseError,
} from '../services/strategy.js';

type Options = { prisma: AppPrisma };
type IdParams = { Params: { id: string } };

export async function strategyRoutes(app: FastifyInstance, { prisma }: Options) {
  const svc = createStrategyService(prisma);
  const base = '/api/v1/strategies';

  app.setErrorHandler((err, request, reply) => {
    if (err instanceof ZodError) return reply.code(400).send({ error: 'VALIDATION_ERROR', issues: err.issues });
    if (err instanceof StrategyNotFoundError) return reply.code(404).send({ error: err.message });
    if (err instanceof StrategyInUseError) return reply.code(409).send({ error: err.message });
    request.log.error({ err }, 'Strategy route failed');
    return reply.code(500).send({ error: 'STRATEGY_QUERY_FAILED' });
  });

  app.get(base, async () => ({ data: await svc.list() }));
  app.get<IdParams>(`${base}/:id`, async (req) => ({ data: await svc.get(req.params.id) }));
  app.post(base, async (req, reply) =>
    reply.code(201).send({ data: await svc.create(strategySchema.parse(req.body)) }));
  app.patch<IdParams>(`${base}/:id`, async (req) =>
    ({ data: await svc.update(req.params.id, strategyUpdateSchema.parse(req.body)) }));
  app.patch<IdParams>(`${base}/:id/toggle`, async (req) => ({ data: await svc.toggle(req.params.id) }));
  app.delete<IdParams>(`${base}/:id`, async (req, reply) => {
    await svc.remove(req.params.id);
    return reply.code(204).send();
  });
}